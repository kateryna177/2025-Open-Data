#!/usr/bin/env python3

import os
import sys
import csv
import argparse
from datetime import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from dateutil import parser

sns.set(style="whitegrid")


def safe_parse_date(s):
    
    if pd.isna(s):
        return None
    s = str(s).strip()
    if s == "":
        return None
    try:
        return parser.parse(s, dayfirst=False, yearfirst=False)
    except Exception:
        try:
            return parser.parse(s, dayfirst=True, yearfirst=False)
        except Exception:
            return None


def extract_year(row):
    
    for col in ["ek_pateikimo_data", "ek_patvirtinimo_data", "finasavimo_pasirasymo_data"]:
        if col in row:
            dt = safe_parse_date(row[col])
            if dt:
                return dt.year
    return np.nan


def parse_budget_string(s):
    
    if s is None:
        return 0.0
    s = str(s).strip()
    if s == "" or s.lower() in ["nan", "none"]:
        return 0.0
    s = s.replace(" ", "")
    # Remove currency symbols if any
    for ch in ["€", "Eur", "EUR", "$"]:
        s = s.replace(ch, "")
    has_dot = '.' in s
    has_comma = ',' in s
    try:
        if has_dot and has_comma:
            # assume dot thousands, comma decimal
            s2 = s.replace('.', '').replace(',', '.')
        elif has_comma and not has_dot:
            parts = s.split(',')
            if len(parts[-1]) <= 2:
                s2 = s.replace(',', '.')
            else:
                s2 = s.replace(',', '')
        elif has_dot and not has_comma:
            if s.count('.') > 1:
                s2 = s.replace('.', '')
            else:
                s2 = s
        else:
            s2 = s
        # keep only digits, dot and minus sign
        filtered = ''.join(ch for ch in s2 if (ch.isdigit() or ch in '.-'))
        if filtered == "" or filtered in ['.', '-']:
            return 0.0
        return float(filtered)
    except Exception:
        try:
            # last resort: remove common separators and parse
            return float(s.replace(',', '').replace('.', ''))
        except Exception:
            return 0.0


def to_numeric_budget(x):
    
    try:
        if pd.isna(x):
            return 0.0
        if isinstance(x, (int, float)):
            return float(x)
        return parse_budget_string(x)
    except Exception:
        return 0.0


def main():
    parser_arg = argparse.ArgumentParser(description="Analyze Projektas.csv")
    parser_arg.add_argument(
        "--input",
        "-i",
        required=False,
        default="Projektas.csv",
        help="Path to Projektas.csv (e.g. data\\Projektas.csv)",
    )
    parser_arg.add_argument(
        "--out", "-o", default="outputs", help="Output folder for results (default: outputs)"
    )
    args = parser_arg.parse_args()

    INPUT_CSV = args.input
    OUTPUT_DIR = args.out
    REPORT_MD = os.path.join(OUTPUT_DIR, "report_generated.md")

    if not os.path.exists(INPUT_CSV):
        print(f"ERROR: Input file not found: {INPUT_CSV}")
        print("Try: python analyze_projektas.py --input data\\Projektas.csv")
        sys.exit(1)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Read CSV: try utf-8 first, then latin1
    try:
        df = pd.read_csv(INPUT_CSV, dtype=str, quoting=csv.QUOTE_MINIMAL, low_memory=False)
    except Exception:
        df = pd.read_csv(INPUT_CSV, dtype=str, encoding="latin1", quoting=csv.QUOTE_MINIMAL, low_memory=False)

    # Normalize column names
    df.columns = [c.strip() for c in df.columns]

    # Columns of interest (if present)
    cols_of_interest = [
        "_type",
        "_id",
        "_revision",
        "_page.next",
        "id",
        "istaiga",
        "projekto_pav_en",
        "statusas",
        "tikslas_en",
        "sutarciu_kiekis",
        "finasavimo_pasirasymo_data",
        "finansavimas",
        "ek_pateikimo_data",
        "ek_patvirtinimo_data",
        "finansavimo_mechanizmas",
        "projekto_biudzetas",
        "valiuta",
    ]
    cols_present = [c for c in cols_of_interest if c in df.columns]
    if len(cols_present) == 0:
        df_sub = df.copy()
    else:
        df_sub = df[cols_present].copy()

    # Parse numeric budget
    if "projekto_biudzetas" in df_sub.columns:
        df_sub["projekto_biudzetas_num"] = df_sub["projekto_biudzetas"].apply(to_numeric_budget)
    else:
        df_sub["projekto_biudzetas_num"] = 0.0

    # Extract year
    df_sub["year"] = df_sub.apply(extract_year, axis=1)

    # Normalize currency column
    if "valiuta" in df_sub.columns:
        df_sub["valiuta"] = df_sub["valiuta"].fillna("").str.strip().replace("", "Unknown")
    else:
        df_sub["valiuta"] = "Unknown"

    total_projects = len(df_sub)
    total_budget = df_sub["projekto_biudzetas_num"].sum()

    # Group by implementing body (istaiga)
    if "istaiga" in df_sub.columns:
        grp_istaiga = (
            df_sub.groupby("istaiga", dropna=False)["projekto_biudzetas_num"]
            .agg(["sum", "count"])
            .reset_index()
        )
        grp_istaiga = grp_istaiga.sort_values("sum", ascending=False)
        grp_istaiga.to_csv(os.path.join(OUTPUT_DIR, "top_institutes.csv"), index=False)
    else:
        grp_istaiga = pd.DataFrame()

    # Top-10 plot
    try:
        if not grp_istaiga.empty:
            top10 = grp_istaiga.head(10)
            plt.figure(figsize=(10, 6))
            sns.barplot(data=top10, x="sum", y="istaiga", palette="viridis")
            plt.xlabel("Total budget (approx.)")
            plt.ylabel("Implementing body (istaiga)")
            plt.title("Top 10 implementing bodies by total project budget")
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, "top_institutes.png"), dpi=150)
            plt.close()
    except Exception as e:
        print("Error building top-10 plot:", e)

    # Budget and project count per year
    df_year = df_sub.dropna(subset=["year"]).copy()
    if not df_year.empty:
        df_year["year"] = df_year["year"].astype(int)
        budget_per_year = df_year.groupby("year")["projekto_biudzetas_num"].sum().reset_index()
        projects_per_year = df_year.groupby("year").size().reset_index(name="projects_count")
        budget_per_year.to_csv(os.path.join(OUTPUT_DIR, "budget_per_year.csv"), index=False)
        projects_per_year.to_csv(os.path.join(OUTPUT_DIR, "projects_per_year.csv"), index=False)

        try:
            plt.figure(figsize=(10, 6))
            sns.lineplot(data=budget_per_year, x="year", y="projekto_biudzetas_num", marker="o")
            plt.xlabel("Year")
            plt.ylabel("Total budget")
            plt.title("Total project budget by year")
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, "budget_per_year.png"), dpi=150)
            plt.close()

            plt.figure(figsize=(10, 6))
            sns.barplot(data=projects_per_year, x="year", y="projects_count", color="steelblue")
            plt.xlabel("Year")
            plt.ylabel("Number of projects")
            plt.title("Number of projects by year")
            plt.tight_layout()
            plt.savefig(os.path.join(OUTPUT_DIR, "projects_per_year.png"), dpi=150)
            plt.close()
        except Exception as e:
            print("Error building year-based plots:", e)

    # Save cleaned CSV
    df_sub.to_csv(os.path.join(OUTPUT_DIR, "projektas_cleaned.csv"), index=False)

    # Generate markdown report
    with open(REPORT_MD, "w", encoding="utf-8") as f:
        f.write("# Projektas.csv analysis\n\n")
        f.write(f"- Input file: {INPUT_CSV}\n\n")
        f.write("## Summary\n\n")
        f.write(f"- Total records: **{total_projects}**\n")
        f.write(f"- Total budget (from field projekto_biudzetas): **{total_budget:,.2f}**\n\n")
        if not grp_istaiga.empty:
            f.write("## Top implementing bodies by budget (file: top_institutes.csv)\n\n")
            f.write("![top_institutes](top_institutes.png)\n\n")
        f.write("## Budget and projects by year\n\n")
        if os.path.exists(os.path.join(OUTPUT_DIR, "budget_per_year.png")):
            f.write("![budget_per_year](budget_per_year.png)\n\n")
        if os.path.exists(os.path.join(OUTPUT_DIR, "projects_per_year.png")):
            f.write("![projects_per_year](projects_per_year.png)\n\n")
        f.write("## Generated files\n\n")
        f.write(
            "- projektas_cleaned.csv\n- top_institutes.csv\n- budget_per_year.csv\n- projects_per_year.csv\n- top_institutes.png, budget_per_year.png, projects_per_year.png\n\n"
        )
        f.write("----\n")
        f.write("Script: analyze_projektas.py\n")

    print("Analysis complete. Results saved to:", OUTPUT_DIR)
    print("Report:", REPORT_MD)


if __name__ == "__main__":
    main()