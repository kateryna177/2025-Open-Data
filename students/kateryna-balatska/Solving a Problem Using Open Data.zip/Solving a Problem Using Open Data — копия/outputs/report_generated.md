# Projektas.csv analysis

- Input file: Projektas.csv

## Summary

- Total records: **170**
- Total budget (from field projekto_biudzetas): **901,074,370.00**

## Top implementing bodies by budget (file: top_institutes.csv)

![top_institutes](top_institutes.png)

## Budget and projects by year

![budget_per_year](budget_per_year.png)

![projects_per_year](projects_per_year.png)

## Generated files

- projektas_cleaned.csv
- top_institutes.csv
- budget_per_year.csv
- projects_per_year.csv
- top_institutes.png, budget_per_year.png, projects_per_year.png

----
Script: analyze_projektas.py
