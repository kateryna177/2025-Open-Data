from typing import List, Optional

import pandas as pd


def filter_df(df: pd.DataFrame,
              countries: List[str] = None,
              sectors: List[str] = None,
              year_min: int = None,
              year_max: int = None) -> pd.DataFrame:
    """Filter dataframe by countries, sectors and year range."""
    out = df.copy()
    if countries:
        out = out[out['geo'].isin(countries)]
    if sectors:
        out = out[out['sector'].isin(sectors)]
    if year_min is not None:
        out = out[out['year'] >= year_min]
    if year_max is not None:
        out = out[out['year'] <= year_max]
    return out


def total_by_country_and_year(df: pd.DataFrame,
                              year: int,
                              sector: Optional[str] = None) -> pd.DataFrame:
    """Return total expenditure by country for a given year.

    If sector is provided (string), filter by that sector.
    If sector is None, aggregate across all sectors for the year.
    """
    filt = df[df['year'] == year]
    if sector:
        filt = filt[filt['sector'] == sector]
    if filt.empty:
        return pd.DataFrame(columns=['geo', 'value'])
    res = filt.groupby('geo', as_index=False)['value'].sum()
    res = res.sort_values('value', ascending=False).reset_index(drop=True)
    return res


def top_countries_by_year(df: pd.DataFrame,
                          year: int,
                          n: int = 10,
                          sector: Optional[str] = None) -> pd.DataFrame:
    """Return top n countries by expenditure for given year.

    If sector is None, data is aggregated across sectors.
    """
    totals = total_by_country_and_year(df, year, sector)
    return totals.head(n)


def trend_for_country_and_sector(df: pd.DataFrame, country: str,
                                 sector: str) -> pd.DataFrame:
    """Return time series (year, value) for a country and sector sorted by year."""
    filt = df[(df['geo'] == country) & (df['sector'] == sector)]
    if filt.empty:
        return pd.DataFrame(columns=['year', 'value'])
    ts = filt.groupby('year', as_index=False)['value'].sum().sort_values('year')
    return ts


def aggregate_sector_shares_for_year(df: pd.DataFrame, year: int,
                                     country: str) -> pd.DataFrame:
    """Return each sector's share of total for the given country and year."""
    filt = df[(df['year'] == year) & (df['geo'] == country)]
    agg = filt.groupby('sector', as_index=False)['value'].sum()
    total = agg['value'].sum()
    if total == 0:
        agg['share'] = 0.0
    else:
        agg['share'] = agg['value'] / total
    agg = agg.sort_values('value', ascending=False).reset_index(drop=True)
    return agg