import os
from typing import Tuple

import pandas as pd


def load_and_clean_csv(file_path: str) -> pd.DataFrame:
    """Load CSV file and perform basic cleaning.

    Expected CSV columns:
    DATAFLOW, LAST UPDATE, freq, sector, unit, geo, TIME_PERIOD, OBS_VALUE, OBS_FLAG, CONF_STATUS
    Returns a DataFrame with standardized column names:
    ['sector', 'unit', 'geo', 'year', 'value', 'obs_flag', 'conf_status']
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f'File not found: {file_path}')

    df = pd.read_csv(file_path, dtype=str)
    keep = {
        'sector': 'sector',
        'unit': 'unit',
        'geo': 'geo',
        'TIME_PERIOD': 'year',
        'OBS_VALUE': 'value',
        'OBS_FLAG': 'obs_flag',
        'CONF_STATUS': 'conf_status'
    }

    col_map = {}
    for c in df.columns:
        up = c.upper()
        for k in keep:
            if up == k.upper():
                col_map[c] = keep[k]
    df = df.rename(columns=col_map)
    required = ['sector', 'unit', 'geo', 'year', 'value']
    for col in required:
        if col not in df.columns:
            raise KeyError(f"Required column '{col}' not in CSV. Found columns: {list(df.columns)}")

    df['year'] = pd.to_numeric(df['year'], errors='coerce').astype('Int64')
    df['value'] = pd.to_numeric(df['value'], errors='coerce')
    df = df.dropna(subset=['year', 'value'])
    df['sector'] = df['sector'].str.strip()
    df['geo'] = df['geo'].str.strip()
    df['unit'] = df['unit'].str.strip()
    df = df[['sector', 'unit', 'geo', 'year', 'value', 'obs_flag', 'conf_status']]
    df = df.reset_index(drop=True)
    return df


def load_sample(file_path: str, max_rows: int = 100) -> pd.DataFrame:
    """Load a sample for quick inspection."""
    df = load_and_clean_csv(file_path)
    return df.head(max_rows)