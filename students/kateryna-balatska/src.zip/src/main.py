import argparse
import sys
from pathlib import Path

from data_loader import load_and_clean_csv, load_sample
from analyzer import (aggregate_sector_shares_for_year,
                      top_countries_by_year, trend_for_country_and_sector)
from visualizer import (bar_plot_top_countries, line_plot_trend,
                        stacked_bar_sectors)


def cmd_sample(args: argparse.Namespace) -> None:
    df = load_sample(args.file, max_rows=args.max_rows)
    print(df.to_string(index=False))


def cmd_top(args: argparse.Namespace) -> None:
    df = load_and_clean_csv(args.file)
    sector = args.sector if args.sector else None
    totals = top_countries_by_year(df, args.year, n=args.n, sector=sector)
    if totals.shape[0] <= 1:
        print(f"Warning: only {totals.shape[0]} country(ies) found for year={args.year}"
              f"{'' if sector is None else f', sector={sector!r}'}.\n"
              "This may be due to missing data for that year or the applied sector filter.")
    if totals.empty:
        print("No data found for the requested year/sector.")
        return
    print(totals.to_string(index=False))
    if args.out:
        bar_plot_top_countries(totals, args.year, args.sector or 'All sectors', out_file=args.out)
        print(f'Bar chart saved to {args.out}')


def cmd_trend(args: argparse.Namespace) -> None:
    df = load_and_clean_csv(args.file)
    ts = trend_for_country_and_sector(df, args.country, args.sector)
    if ts.empty:
        print('No time series available for that country/sector.')
        return
    print(ts.to_string(index=False))
    if args.out:
        line_plot_trend(ts, args.country, args.sector, out_file=args.out)
        print(f'Line chart saved to {args.out}')


def cmd_sectors(args: argparse.Namespace) -> None:
    df = load_and_clean_csv(args.file)
    shares = aggregate_sector_shares_for_year(df, args.year, args.country)
    if shares.empty:
        print('No data for selected country/year.')
        return
    print(shares.to_string(index=False))
    if args.out_plot:
        stacked_bar_sectors(df, args.country, args.year - args.span + 1,
                            args.year, out_file=args.out_plot)
        print(f'Stacked bar chart saved to {args.out_plot}')


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description='Environmental protection expenditure analysis'
    )
    parser.add_argument('--file', '-f', required=True,
                        help='Path to data.csv')

    sub = parser.add_subparsers(dest='command', required=True)

    p_sample = sub.add_parser('sample', help='Show a data sample')
    p_sample.add_argument('--max-rows', type=int, default=20)
    p_sample.set_defaults(func=cmd_sample)

    p_top = sub.add_parser('top', help='Show top countries by year')
    p_top.add_argument('--year', type=int, required=True)
    p_top.add_argument('--n', type=int, default=10)
 
    p_top.add_argument('--sector', type=str, default=None,
                       help='Sector to filter by (omit to aggregate across sectors)')
    p_top.add_argument('--out', type=str, help='Save bar chart to file (png)')
    p_top.set_defaults(func=cmd_top)

    p_trend = sub.add_parser('trend', help='Show trend for a country and sector')
    p_trend.add_argument('--country', type=str, required=True)
    p_trend.add_argument('--sector', type=str, default='Total economy')
    p_trend.add_argument('--out', type=str, help='Save line chart to file (png)')
    p_trend.set_defaults(func=cmd_trend)

    p_sectors = sub.add_parser('sectors',
                               help='Sector shares for a country in a given year')
    p_sectors.add_argument('--country', type=str, required=True)
    p_sectors.add_argument('--year', type=int, required=True)
    p_sectors.add_argument('--span', type=int, default=5,
                           help='Span of years to plot (for stacked bar)')
    p_sectors.add_argument('--out-plot', type=str, help='Save stacked bar chart to file (png)')
    p_sectors.set_defaults(func=cmd_sectors)

    return parser


def main(argv=None):
    argv = argv or sys.argv[1:]
    parser = build_parser()
    args = parser.parse_args(argv)

    args.file = str(Path(args.file).expanduser())
    args.func(args)


if __name__ == '__main__':
    main()