from typing import Optional

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd


sns.set(style='whitegrid')


def line_plot_trend(ts: pd.DataFrame,
                    country: str,
                    sector: str,
                    out_file: Optional[str] = None) -> None:
    """Plot a line trend for a time series DataFrame with columns ['year','value']."""
    if ts.empty:
        raise ValueError('Empty time series provided to plot.')

    plt.figure(figsize=(8, 4.5))
    plt.plot(ts['year'], ts['value'], marker='o', linestyle='-')
    plt.title(f'{sector} — {country}')
    plt.xlabel('Year')
    plt.ylabel('Million euro')
    plt.tight_layout()
    if out_file:
        plt.savefig(out_file, dpi=150)
    else:
        plt.show()
    plt.close()


def bar_plot_top_countries(totals: pd.DataFrame,
                           year: int,
                           sector: str,
                           out_file: Optional[str] = None) -> None:
    """Bar plot for top countries totals DataFrame with columns ['geo','value']."""
    if totals.empty:
        raise ValueError('Empty totals provided to plot.')

    plt.figure(figsize=(10, 5))
    sns.barplot(x='value', y='geo', data=totals, palette='viridis')
    plt.title(f'Top countries by {sector} — {year}')
    plt.xlabel('Million euro')
    plt.ylabel('Country')
    plt.tight_layout()
    if out_file:
        plt.savefig(out_file, dpi=150)
    else:
        plt.show()
    plt.close()


def stacked_bar_sectors(df: pd.DataFrame,
                        country: str,
                        year_min: int,
                        year_max: int,
                        out_file: Optional[str] = None) -> None:
    """Stacked bar chart showing sector composition across years for a country."""
    filt = df[(df['geo'] == country) &
              (df['year'] >= year_min) &
              (df['year'] <= year_max)]
    if filt.empty:
        raise ValueError('No data to plot for the selected country/year range.')

    pivot = filt.pivot_table(index='year', columns='sector', values='value',
                             aggfunc='sum', fill_value=0)
    pivot = pivot.sort_index()
    pivot.plot(kind='bar', stacked=True, figsize=(12, 6), colormap='tab20')
    plt.title(f'Sector composition — {country} ({year_min}-{year_max})')
    plt.ylabel('Million euro')
    plt.xlabel('Year')
    plt.legend(bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.tight_layout()
    if out_file:
        plt.savefig(out_file, dpi=150)
    else:
        plt.show()
    plt.close()